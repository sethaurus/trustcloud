public class TCSocketException extends Exception {
  public TCSocketException(String message) {
    super(message);
  }
}