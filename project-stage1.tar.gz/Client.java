public class Client {
  public static void main(String[] args) {
    System.out.println("TrustCloud Client");
    System.out.println("CITS3002 - Thomas Drake-Brockman (21150739)");

    try {
      TCSocket sock = new TCSocketFactory("localhost", 4213).open();
      System.out.println("Connected to server.\n");

      // Vouching

      sock.write("v");

      System.out.println("Disconnected from server.\n");
    } catch (TCSocketException e) {
      System.out.println(e.getMessage());
      return;
    }
  }
}