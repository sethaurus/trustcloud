import java.io.*;
import java.net.*;
import javax.net.ssl.*;
import java.security.*;
import java.security.cert.*;

public class Server {
  public static void main(String[] args) {
    System.out.println("TrustCloud Server");
    System.out.println("CITS3002 - Thomas Drake-Brockman (21150739)\n");  

    try {
      TCServerSocket serverSock = new TCServerSocketFactory(4213).open();
      System.out.println("Bound on port 4213. Awaiting connections.\n");

      while (true) {
        TCSocket socket = serverSock.accept();

        System.out.println("Client has connected.");
        socket.drain();

        // Read a byte n to determine length of next command,
        // then read n bytes and deserialize into command instance.
        
        System.out.println("Client has disconnected.");
      }
    } catch (TCSocketException e) {
      System.out.println(e.getMessage());
      return;
    }
  }
}