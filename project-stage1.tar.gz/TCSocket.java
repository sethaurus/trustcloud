import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import javax.net.ssl.SSLSocket;

public class TCSocket {
  private SSLSocket sock;
  private InputStream sockIn;
  private OutputStream sockOut;

  public TCSocket(SSLSocket sock) throws TCSocketException {
    this.sock = sock;
    try {
      this.sockOut = sock.getOutputStream();
      this.sockIn = sock.getInputStream();
    } catch (IOException e) {
      throw new TCSocketException("Unable to open socket streams.");
    }
  }

  public void write(String str) throws TCSocketException {
    try {
      sockOut.write(str.getBytes(Charset.forName("UTF-8")));
    } catch (IOException e) {
      throw new TCSocketException("Failed to write message to socket.");
    }
  }

  public byte[] read(int len) {
    
  }

  public void drain() throws TCSocketException {
    try {
      while (sockIn.read() != -1) {}
    } catch (IOException e) {
      throw new TCSocketException("Failed to read from socket.");
    }
  }
}