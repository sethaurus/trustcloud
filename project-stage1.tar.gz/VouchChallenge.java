import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

class VouchChallenge {
  private String filename;
  private String cert;

  public VouchChallenge(String filename, String cert) {
    this.filename = filename;
    this.cert = cert;
  }

  public byte[] set() {

  }

  public boolean verify(byte[] response) {

  }

  private getHash() {
    MessageDigest digest = MessageDigest.getInstance("SHA-256");
    // return SHA-256 has of file.
  }
}