import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

class VouchResponse {
  private String cert;

  public VouchResponse(String cert) {
    this.cert = cert;
  }

  public byte[] response(byte[] challenge) {

  }

  private getPrivateKey() {
    // We assume that the .key file exists in the current directory.
  }
}